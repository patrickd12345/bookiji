import CacheManagementDashboard from '@/components/admin/CacheManagementDashboard'

export default function CacheManagementPage() {
  return <CacheManagementDashboard />
}
