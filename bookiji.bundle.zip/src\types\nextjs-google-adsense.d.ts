declare module 'nextjs-google-adsense' {
  const GoogleAdsense: React.FC<Record<string, unknown>>
  export default GoogleAdsense
  export { GoogleAdsense }
}
