export interface Notification {
  id: string;
  name: string;
  avatar_url?: string;
  message: string;
  created_at: string;
} 