// Clean re-export to maintain backward compatibility
// This file re-exports everything from guidedTourSimple to avoid import errors

export * from './guidedTourSimple';
export { default } from './guidedTourSimple'; 