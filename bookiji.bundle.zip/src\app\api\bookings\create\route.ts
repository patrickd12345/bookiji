﻿import { makeBookingsCreateHandler } from '@/lib/bookingsCreateHandler'

export const POST = makeBookingsCreateHandler()
